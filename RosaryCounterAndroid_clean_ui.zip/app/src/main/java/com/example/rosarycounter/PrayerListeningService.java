package com.example.rosarycounter;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.os.*;
import android.speech.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class PrayerListeningService extends Service {
    private SpeechRecognizer recognizer;
    private WindowManager windowManager;
    private View overlay;
    private TextView englishCountView, latinCountView, overlayStatus;
    private int englishCount = 0, latinCount = 0;
    private String language = "en-US";
    private long lastCountAt = 0;
    private String lastMatchedText = "";
    private Handler handler = new Handler(Looper.getMainLooper());

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? "START" : intent.getAction();
        if ("STOP".equals(action)) {
            stopListening(); removeOverlay(); stopForeground(true); stopSelf(); return START_NOT_STICKY;
        }
        if ("RESET".equals(action)) {
            englishCount = 0; latinCount = 0; lastCountAt = 0; lastMatchedText = "";
            updateOverlay("Counters reset"); return START_NOT_STICKY;
        }
        if (intent != null && intent.getStringExtra("language") != null) language = intent.getStringExtra("language");
        startForeground(77, notification());
        showOverlay();
        startListening();
        return START_STICKY;
    }

    private Notification notification() {
        return new Notification.Builder(this, "rosary_counter")
            .setContentTitle("Rosary Counter is listening")
            .setContentText("Voice counting is active. Return to the app to stop.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("rosary_counter", "Rosary Counter", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void showOverlay() {
        if (overlay != null) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(12), dp(16), dp(12));
        box.setBackgroundColor(0xF2382545);
        TextView heading = new TextView(this);
        heading.setText("🙏 ROSARY COUNTER");
        heading.setTextColor(0xFFFFFFFF);
        heading.setTextSize(12);
        heading.setTypeface(null, android.graphics.Typeface.BOLD);
        box.addView(heading);

        englishCountView = new TextView(this);
        englishCountView.setText("Hail Marys: 0 / 10");
        englishCountView.setTextColor(0xFFFFFFFF);
        englishCountView.setTextSize(15);
        englishCountView.setPadding(0, dp(7), 0, 0);
        box.addView(englishCountView);

        latinCountView = new TextView(this);
        latinCountView.setText("Ave Marias: 0 / 10");
        latinCountView.setTextColor(0xFFE8DDF7);
        latinCountView.setTextSize(15);
        latinCountView.setPadding(0, dp(4), 0, 0);
        box.addView(latinCountView);

        overlayStatus = new TextView(this);
        overlayStatus.setText("Listening: English");
        overlayStatus.setTextColor(0xFFD8C8EB);
        overlayStatus.setTextSize(11);
        overlayStatus.setPadding(0, dp(6), 0, 0);
        box.addView(overlayStatus);
        overlay = box;

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.END; params.x = dp(12); params.y = dp(150);
        overlay.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; return true; }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    params.x = startX + (int)(downX-e.getRawX());
                    params.y = startY + (int)(e.getRawY()-downY);
                    windowManager.updateViewLayout(overlay, params); return true;
                }
                return true;
            }
        });
        windowManager.addView(overlay, params);
        refreshCounts();
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateStatus("Speech recognition unavailable"); return;
        }
        stopListening();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) {}
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float rms) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() {}
            public void onError(int error) { scheduleRestart(); }
            public void onResults(Bundle results) { handleResults(results); scheduleRestart(); }
            public void onPartialResults(Bundle results) { handleResults(results); }
            public void onEvent(int t, Bundle p) {}
        });
        restart();
    }

    private void scheduleRestart() {
        handler.postDelayed(() -> restart(), 900);
    }

    private void restart() {
        if (recognizer == null) return;
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, language);
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            recognizer.startListening(i);
        } catch (Exception ignored) {}
    }

    private void handleResults(Bundle b) {
        ArrayList<String> matches = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (matches == null || matches.isEmpty()) return;
        String value = matches.get(0).toLowerCase(Locale.ROOT);
        long now = System.currentTimeMillis();
        if (value.equals(lastMatchedText) && now - lastCountAt < 8000) return;

        boolean english = value.contains("hail mary") || value.contains("full of grace") ||
            value.contains("blessed art thou") || value.contains("blessed are you");
        boolean latin = value.contains("ave maria") || value.contains("gratia plena") ||
            value.contains("dominus tecum") || value.contains("benedicta tu");
        boolean match = language.startsWith("en") ? english : latin;

        if (match && now - lastCountAt > 5000) {
            lastCountAt = now; lastMatchedText = value;
            if (language.startsWith("en")) englishCount++; else latinCount++;
            if ((language.startsWith("en") && englishCount >= 10) || (language.equals("la") && latinCount >= 10)) {
                String completed = language.startsWith("en") ? "10 Hail Marys complete!" : "10 Ave Marias complete!";
                updateStatus("🔔 " + completed);
                ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(78,
                    new Notification.Builder(this, "rosary_counter")
                        .setContentTitle("Rosary Counter")
                        .setContentText(completed)
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setAutoCancel(true).build());
                try { ((android.media.AudioManager)getSystemService(AUDIO_SERVICE)).playSoundEffect(SoundEffectConstants.CLICK); } catch(Exception ignored) {}
                if (language.startsWith("en")) englishCount = 0; else latinCount = 0;
            }
            refreshCounts();
        }
    }

    private void refreshCounts() {
        handler.post(() -> {
            if (englishCountView != null) englishCountView.setText("Hail Marys: " + englishCount + " / 10");
            if (latinCountView != null) latinCountView.setText("Ave Marias: " + latinCount + " / 10");
            if (overlayStatus != null) overlayStatus.setText("Listening: " + (language.startsWith("en") ? "English" : "Latin"));
        });
    }
    private void updateStatus(String s) {
        handler.post(() -> { if (overlayStatus != null) overlayStatus.setText(s); });
    }
    private void updateOverlay(String s) {
        refreshCounts(); updateStatus(s);
    }
    private void stopListening() {
        handler.removeCallbacksAndMessages(null);
        if (recognizer != null) { try { recognizer.cancel(); recognizer.destroy(); } catch(Exception ignored) {} recognizer = null; }
    }
    private void removeOverlay() {
        if (overlay != null) { try { windowManager.removeView(overlay); } catch(Exception ignored) {} overlay = null; }
        englishCountView = null; latinCountView = null; overlayStatus = null;
    }
    @Override public void onDestroy() { stopListening(); removeOverlay(); super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
