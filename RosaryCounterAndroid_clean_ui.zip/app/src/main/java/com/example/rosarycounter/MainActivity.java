package com.example.rosarycounter;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    private TextView statusView;
    private Spinner languages;

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(16), dp(18), dp(16));
        c.setBackgroundColor(Color.WHITE);
        return c;
    }

    private void addSpace(LinearLayout root, int h) {
        android.view.View v = new android.view.View(this);
        root.addView(v, new LinearLayout.LayoutParams(1, dp(h)));
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(37, 30, 54));
        getWindow().setNavigationBarColor(Color.rgb(37, 30, 54));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(247, 244, 251));

        TextView title = text("Rosary Counter", 28, Color.rgb(48, 37, 69), true);
        root.addView(title);
        TextView subtitle = text("Stay present in prayer. We'll keep count.", 14, Color.rgb(104, 96, 116), false);
        root.addView(subtitle);

        addSpace(root, 22);
        LinearLayout counters = card();
        counters.setBackgroundColor(Color.WHITE);
        counters.addView(text("YOUR DECADE", 12, Color.rgb(119, 91, 153), true));
        addSpace(counters, 12);

        LinearLayout englishRow = new LinearLayout(this);
        englishRow.setGravity(Gravity.CENTER_VERTICAL);
        englishRow.addView(text("Hail Marys (English)", 16, Color.rgb(48, 37, 69), true),
            new LinearLayout.LayoutParams(0, -2, 1));
        englishRow.addView(text("0 / 10", 23, Color.rgb(94, 66, 137), true));
        counters.addView(englishRow);

        addSpace(counters, 16);
        android.view.View divider = new android.view.View(this);
        divider.setBackgroundColor(Color.rgb(235, 230, 241));
        counters.addView(divider, new LinearLayout.LayoutParams(-1, dp(1)));
        addSpace(counters, 16);

        LinearLayout latinRow = new LinearLayout(this);
        latinRow.setGravity(Gravity.CENTER_VERTICAL);
        latinRow.addView(text("Ave Marias (Latin)", 16, Color.rgb(48, 37, 69), true),
            new LinearLayout.LayoutParams(0, -2, 1));
        latinRow.addView(text("0 / 10", 23, Color.rgb(94, 66, 137), true));
        counters.addView(latinRow);
        root.addView(counters);

        addSpace(root, 18);
        LinearLayout setup = card();
        setup.addView(text("VOICE RECOGNITION", 12, Color.rgb(119, 91, 153), true));
        addSpace(setup, 8);
        setup.addView(text("Choose the language you'll pray in. The floating counter stays visible over other apps.", 14, Color.rgb(104, 96, 116), false));
        addSpace(setup, 12);
        languages = new Spinner(this);
        languages.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
            new String[]{"English — Hail Mary", "Latin — Ave Maria"}));
        setup.addView(languages);
        root.addView(setup);

        addSpace(root, 18);
        Button start = new Button(this);
        start.setText("Start praying");
        start.setTextColor(Color.WHITE);
        start.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(94, 66, 137)));
        start.setOnClickListener(v -> {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10); return;
            }
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11); return;
            }
            if (!Settings.canDrawOverlays(this)) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                Toast.makeText(this, "Allow display over other apps, then return and tap Start praying.", Toast.LENGTH_LONG).show(); return;
            }
            Intent i = new Intent(this, PrayerListeningService.class);
            i.setAction("START");
            i.putExtra("language", languages.getSelectedItemPosition() == 0 ? "en-US" : "la");
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            statusView.setText("Listening for prayers. You can switch apps; use the floating counter to follow your decade.");
        });
        root.addView(start, new LinearLayout.LayoutParams(-1, dp(54)));

        Button stop = new Button(this);
        stop.setText("Stop listening");
        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, PrayerListeningService.class); i.setAction("STOP"); startService(i);
            statusView.setText("Listening stopped.");
        });
        root.addView(stop);

        Button reset = new Button(this);
        reset.setText("Reset both counts");
        reset.setOnClickListener(v -> {
            Intent i = new Intent(this, PrayerListeningService.class); i.setAction("RESET"); startService(i);
            statusView.setText("Both counters reset.");
        });
        root.addView(reset);

        statusView = text("Not listening yet. Select English or Latin, then tap Start praying.", 14, Color.rgb(104, 96, 116), false);
        statusView.setPadding(0, dp(12), 0, 0);
        root.addView(statusView);

        scroll.addView(root);
        setContentView(scroll);
    }
}
