# Rosary Counter Android starter project

Features in this starter:
- Android app shell for voice counting in English or Latin locale selection
- Floating overlay counter designed to stay over other apps
- Foreground notification while listening
- Alert/notification after ten detected prayers

## Important limitations
- This is source code, **not a compiled APK**.
- The Latin speech-recognition locale (`la`) may not be supported by the speech engine installed on a device. On many Android devices, speech recognition is cloud/provider-based and language availability varies.
- Voice matching is a prototype heuristic, not a verified prayer-recognition system. Partial speech results may cause missed or duplicate counts; test carefully before relying on it. The current prototype requires a phrase match and a cooldown.
- Android versions and manufacturers restrict microphone foreground services and overlay permissions. Grant microphone, notification, and “display over other apps” permissions when prompted.
- A production-quality build should be tested on a real Android device and should improve phrase segmentation, duplicate suppression, restart behavior, and accessibility.
- Build using Android Studio with Android SDK installed: open this folder, sync Gradle, then Build > Build Bundle(s) / APK(s) > Build APK(s).


## Build APK online with GitHub Actions (tablet-only option)
1. Create a GitHub repository and upload the *contents* of this project folder (not just the ZIP file).
2. Keep the `.github/workflows/build-apk.yml` file in that exact path.
3. Open the repository's **Actions** tab. If prompted, enable workflows.
4. Select **Build Rosary Counter APK**, tap **Run workflow**, and wait for it to finish successfully.
5. Open the successful run, find **Artifacts**, and download `RosaryCounter-debug-apk`. Extract the downloaded artifact ZIP to get `app-debug.apk`.

The workflow uses Gradle 8.9 and Java 17 on GitHub's runner. This is a debug APK for testing, not a Play Store release.


## UI and counter update
- Updated main screen with a cleaner card-style layout.
- Floating overlay shows separate `Hail Marys: n/10` and `Ave Marias: n/10` rows.
- The selected recognition language increments its matching counter and triggers a notification at ten, then resets that language's decade count.
- Note: Android speech-recognition support for Latin varies by installed provider. Voice recognition is heuristic and needs device testing.
